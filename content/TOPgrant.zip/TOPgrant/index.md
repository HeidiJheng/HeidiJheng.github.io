---
title: TOP Grants (Taiwanese Overseas Pioneers Grants)
# date: "2023-07-32T00:00:00Z"
# lastmod: "023-07-32T00:00:00Z"
categories:
  - grant
tags:
  - grant
slug: letter-of-rec
image:
  caption: ''
  focal_point: ''
---


Thrilled to be awarded the [TOP Grants (Taiwanese Overseas Pioneers Grants)].(https://top.stpi.narl.org.tw/project/topi/index). by the National Science and Technology Council of Taiwan! It’s a huge support for PhD candidates in humanities and social sciences. Grateful for the USD $30,000 award to advance my dissertation research.
